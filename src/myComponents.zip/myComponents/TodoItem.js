import React from 'react'
import "./Todos.css";


const TodoItem = ({todo, onUpdate, onDelete}) => {
  return (
    <>
    <div className="item"> 
      
      <h4>{todo.title}</h4>
      <p>{todo.desc}</p>
      <button className="btn btn-sm btn-warning" onClick={()=>{onUpdate(todo)}}>Update</button>{" "}
      <button className="btn btn-sm btn-danger" onClick={()=>{onDelete(todo)}}>Delete</button>
    </div>
    <hr/>
    </>
  )
}

export default TodoItem
