import React from 'react'

const About = () => {
  return (
    <div>
      This is an about component.
      <p>lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </div>
  )
}

export default About
